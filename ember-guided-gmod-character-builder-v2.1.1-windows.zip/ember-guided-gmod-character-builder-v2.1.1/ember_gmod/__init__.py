"""Ember Guided GMod Character Builder backend."""

__version__ = "2.1.1"
