# Ember Guided Character Builder 2.1.1 verification

Date: 25 July 2026

## Target failure reproduced in logic

The 2.1.0 Jack Hegarty run reported:

```text
maximum displacement: 4.1640
average displacement: 2.7987
minimum edge ratio: 0.1063
maximum edge ratio: 70.8864
before dimensions: 72.0350, 15.2076, 71.9952
after dimensions: 77.9183, 16.7008, 73.7920
```

The previous implementation rejected the entire character solely because the raw maximum edge ratio exceeded 5.0. That is numerically unstable for microscopic decimation edges.

## Corrective implementation

1. Candidate conformance positions are calculated before any vertex is changed.
2. Raw edge extrema remain in the report for diagnosis.
3. Build gating uses meaningful edge length, robust percentiles, absolute change and severe outlier prevalence.
4. A guide to stock mismatch below the compatibility envelope can use the original mesh with the exact stock skeleton.
5. A localized raw edge discontinuity selects the original topology path instead of committing the candidate warp.
6. A widespread edge failure or large skeleton mismatch still stops the build.
7. The posed deformation probe uses the same robust edge analysis.

## Automated results

* Development tests: 38 passed
* Bundled standard library tests: 10 passed
* Python syntax checks: passed
* Exact stock male and female skeleton tests: passed
* Three influence normalization tests: passed
* Microscopic 70x edge regression: passed without blocking
* Widespread 40x edge explosion regression: correctly rejected
* Candidate mesh write occurs only after the decision gate: passed
* Internal 1024 VTF write and complete readback: passed
* Synthetic verified Garry's Mod installation: passed
* Workspace preservation hotfix simulation: passed

## Runtime boundary

This environment did not execute the user's Blender 5.2.0, Garry's Mod StudioMDL or running game. The corrected build must still reach `installed_unverified`, then the game must write the current runtime report.
