# Ember Guided GMod Character Builder 2.1.1

A local Windows workbench for turning a humanoid GLB into a guided Garry's Mod player model and spawnable ragdoll.

The browser talks only to the local Python service at `127.0.0.1`. Imported GLBs and project state remain inside the local `workspace` directory.

## Required software

1. Windows 10 or Windows 11, 64 bit
2. Python 3.10 or newer
3. Blender 4.2 or newer
4. Garry's Mod installed through Steam

## Current workflow

1. Run `verify_v2_guided.bat`.
2. Run `start.bat`.
3. Confirm the Toolchain paths.
4. Import a humanoid GLB.
5. Orient the model and lock the landmark guide.
6. Select **Build + Install**.
7. Restart Garry's Mod completely.
8. Enter Sandbox.
9. Select **Read GMod Runtime Check**.

## 2.1.1 correction

Version 2.1.0 evaluated every mesh through a per bone guide to stock bind warp and blocked the build when one edge ratio exceeded a fixed limit. The Jack Hegarty run proved that logic was unsuitable for generated and decimated meshes: the complete character moved only 4.16 Source units at most and retained valid overall dimensions, while one microscopic edge produced a ratio of 70.886.

Version 2.1.1 now:

1. Evaluates the candidate bind warp without modifying the mesh.
2. Uses meaningful edge length, absolute edge change, percentiles and outlier prevalence rather than one raw ratio.
3. Preserves the original reference topology when the guide is already close to the exact stock bind and the candidate contains localized edge discontinuities.
4. Applies the warp only when its complete diagnostics pass.
5. Uses the same robust diagnostics in the posed deformation probe.
6. Still blocks genuine widespread collapse or explosion before StudioMDL.

For the reported Jack Hegarty measurements, the selected path is expected to be:

```text
original_mesh_exact_stock_bind
```

This means the original mesh is exported without the problematic per bone warp, while the exact stock SMD skeleton and deterministic three influence weights remain in use.

## Installation

A successful build installs the generated Lua, materials and model files directly into Garry's Mod and also creates a managed addon folder. Every direct file is SHA256 checked after copying.

The player model is registered in the stock player model list and through a dedicated client autorun for third party player model selectors.

## Completion rule

Compilation and installation are not treated as final proof. A project becomes complete only when the running game writes a passing runtime report for the current project and build token.

## Existing projects

Minor updates and hotfixes must preserve the entire `workspace` directory. Existing GLBs, landmarks and locked guides do not need to be recreated. Old generated output is deleted and rebuilt.

## Runtime boundary

The package can verify its Python code, project storage, generated contracts, texture writer and synthetic installation locally. Only the user's Windows Blender, StudioMDL and Garry's Mod session can prove the final target character in game.
