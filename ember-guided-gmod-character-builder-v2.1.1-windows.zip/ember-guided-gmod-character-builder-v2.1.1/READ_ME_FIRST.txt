EMBER GUIDED GMOD CHARACTER BUILDER 2.1.1

Close Garry's Mod and every old Builder window before updating.

For the current Jack Hegarty project, apply the cumulative 2.1.1 hotfix to the existing V2 tool folder. The complete workspace, original GLB and locked guide are preserved.

Restart the Builder and confirm Service v2.1.1. Open Jack Hegarty and select Build + Install. The next build discards the old generated model, uses the corrected Source skeleton and axes, validates deformation before compilation, and installs the complete Lua, materials and model runtime automatically.

Fully restart Garry's Mod and enter Sandbox. Return to the Builder and select Read GMod Runtime Check.

A project is never marked Complete until the current game session writes a passing runtime report for the same project and build token.
