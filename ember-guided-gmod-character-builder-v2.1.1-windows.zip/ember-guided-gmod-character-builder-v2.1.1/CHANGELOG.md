# Changelog

## 2.1.1, 25 July 2026

* Replaces the single maximum edge ratio conformance gate with robust edge diagnostics.
* Evaluates guide to stock conformance before changing any vertex.
* Preserves the original mesh when the guide is already stock compatible and the candidate warp contains localized edge discontinuities.
* Adds a deterministic no warp exact stock bind mode for normal T pose and A pose humanoids.
* Applies the same robust edge diagnostics to the posed deformation probe.
* Adds regression coverage for the Jack Hegarty 70.886 edge ratio failure and a genuine widespread exploding mesh case.
* Preserves every existing workspace file when applied as a hotfix.

## 2.1.0, 25 July 2026

* Replaced the old generated skeleton basis with exact stock SMD bind transforms.
* Removed evaluated armature mesh export and automatic bone heat weighting.
* Added deterministic anatomical region weighting with three normalized influences.
* Added automatic verified installation, dedicated client player selector registration and runtime validation.
* Added safe base only Source materials.

## 2.0.4, 25 July 2026

* Replaced the hanging VTEX path with a validated internal VTF 7.2 writer.
